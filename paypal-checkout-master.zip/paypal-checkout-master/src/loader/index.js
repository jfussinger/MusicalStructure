/* @flow */

import { extendNamespace } from '../lib/namespace';

extendNamespace(require('./interface'), [ 'paypal' ]);
