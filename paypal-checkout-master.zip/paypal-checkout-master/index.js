
module.exports = require('./dist/checkout.lib');
module.exports.default = module.exports;
